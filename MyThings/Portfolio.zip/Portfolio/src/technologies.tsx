const TechnologiesData = [
    {
        "id": 1,
        "name": "JavaScript"
    },
    {
        "id": 2,
        "name": "React JS"
    },
    {
        "id": 3,
        "name": "React Native"
    },
    {
        "id": 4,
        "name": "TypeScript"
    },
    {
        "id": 5,
        "name": "NextJs"
    },
    {
        "id": 6,
        "name": "NodeJs"
    },
    {
        "id": 7,
        "name": "Firebase"
    },
    {
        "id": 8,
        "name": "MySQL"
    },
    {
        "id": 9,
        "name": "Git"
    },
    {
        "id": 10,
        "name": "GitHub"
    }
]

export default TechnologiesData;