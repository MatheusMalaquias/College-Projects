import 'styled-components';
import { DefaultTheme } from 'styled-components';

declare module 'styled-components' {
    export interface DefaultTheme  extends DefaultTheme {
        title: string;

        colors: {
            primary: string;
            secundary: string;

            background: string;
            text: string;
            buttonText: string;

            shadow: string;

            backgroundpresentation: string;
            backgroundpresentation780: string;
        }
    }
}